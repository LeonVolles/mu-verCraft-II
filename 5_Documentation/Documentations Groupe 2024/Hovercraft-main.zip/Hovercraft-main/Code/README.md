# Hovercraft
SMR PIST Project on an Mini Hovercraft
